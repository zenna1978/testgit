require 'test_helper'

class MessageThreadsHelperTest < ActionView::TestCase
end
