require 'test_helper'

class PlaceRentalRequestsHelperTest < ActionView::TestCase
end
