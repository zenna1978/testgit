require 'test_helper'

class MessageThreadJoinTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
