require 'test_helper'

class MessageThreadsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
