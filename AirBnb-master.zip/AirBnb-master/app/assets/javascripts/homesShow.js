$(function(){
    $('#date_begin').tooltip();
    $('#date_end').tooltip();
  })