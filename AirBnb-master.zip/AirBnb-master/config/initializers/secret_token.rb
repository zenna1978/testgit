# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Air::Application.config.secret_token = 'd2272b3e9c3cfd98be38c02418567ad9f2b9a78d1838493b296503013ab5ff51cf1b9c7cc2122a6053524358f89f553d0760d6bcd1e9fab1662e5e8590f24d7f'
